---
status: active
doc_type: execution_contract
audience:
  - codex
  - engineer
precedence: 4
supersedes:
  - EXECUTION_HARNESS_CONTRACT.md (legacy version)
  - CODEX_OPERATING_CHARTER.md
  - HARNESS_ENGINEERING_CONTRACT.md
last_updated: 2026-04-16
---

# EXECUTION HARNESS CONTRACT

## Purpose

이 문서는 Codex 가 milestone 을 헛돌지 않고 끝까지 닫기 위한 실행 계약을 고정한다.

핵심 원칙은 하나다.

`중간 진행은 harness 에 쌓고, 사용자에게는 검증된 closeout packet 으로만 보고한다.`

## Harness Package

모든 milestone 은 아래 하네스 자산을 가진다.

- `reports/execution_harness/<task_id>/<lane_id>/manifest.json`
- `reports/execution_harness/<task_id>/<lane_id>/worklog.md`
- `reports/execution_harness/<task_id>/<lane_id>/final_report.json`

## Manifest Minimum

manifest 에는 시작 전에 아래를 고정한다.

- `task_id`
- `lane_id`
- `role`
- `cwd`
- `python_path`
- `worktree_path`
- `write_scope`
- `target_outputs`
- `validation_commands`
- `status`

validation commands 는 구현 전에 먼저 잠근다.

## Lane Model

기본 규칙은 아래다.

- 작은 단일 파일 수정이면 `main` 단독 가능
- subsystem 두 개 이상을 건드리거나, 탐색/구현/검증이 분리되면 병렬 lane 사용
- 병렬 기준 기본형:
  - `main`
  - `explorer`
  - `worker` or `reviewer`

Main lane 은 통합과 최종 verdict 를 맡는다.

## Bootstrap Order

모든 milestone 은 아래 순서로 시작한다.

1. `task scope 잠금`
2. `prepare_execution_harness`
3. `manifest 작성`
4. `validation_commands 확정`
5. `구현`
6. `검증`
7. `final_report 작성`
8. `closeout`

## Validation Loop

검증은 `작업 종류에 맞는 최소 세트`로 고정한다.

### A. Contract / Docs Only

- frontmatter or metadata sanity check
- broken reference / broken file path check
- changed docs 존재 여부 확인

### B. UI / Frontend

- build or type/lint if available
- route smoke for touched surface
- critical rendering check for touched page
- changed artifact path 기록

### C. Backend / Pipeline / Runtime

- focused unit or integration test if available
- pipeline smoke for touched stage
- output artifact existence
- manifest / runtime path / relation refresh evidence

### D. Retrieval / Chat / Corpus

- retrieval regression subset
- citation anchor resolution check
- touched evaluator test via `pytest` if suite exists
- `ragas` or equivalent metric subset if the repo already supports it
- failure case 저장 when the bug is reproducible

검증이 없다면 closeout 도 없다.

## Reporting Model

사용자에게 보이는 보고는 아래 두 번뿐이다.

1. `milestone kickoff`
2. `milestone closeout`

closeout 에는 아래를 포함한다.

- `현재 판단`
- `핵심 근거`
- `산출물 경로`
- `검증 결과`
- `다음 행동`

중간 시도, 복구, 실험 메모는 worklog 로만 남긴다.

## Escalation Rules

아래 경우만 사용자 판단을 요청한다.

- 제품 방향 변경
- 파괴적 삭제
- 외부 비용 또는 보안 판단
- active contract 충돌
- validation target 자체가 비어 있어서 작업 기준을 새로 정해야 하는 경우

그 외는 lane 안에서 복구한다.

## Done Definition

아래를 모두 만족해야 milestone 을 닫을 수 있다.

1. 수정된 코드 또는 문서가 실제로 존재한다.
2. target output 이 생성 또는 갱신됐다.
3. validation command 결과가 남아 있다.
4. 필요한 smoke evidence 가 남아 있다.
5. final_report.json 이 채워졌다.
6. 사용자가 다음 행동을 바로 이해할 수 있다.

`거의 됐다`, `대충 된다`, `아마 맞다` 같은 문장은 closeout verdict 로 쓰지 않는다.
