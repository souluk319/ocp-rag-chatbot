---
status: active
doc_type: entrypoint
audience:
  - codex
  - engineer
precedence: 1
supersedes:
  - AGENTS.md (legacy version)
  - CODEX_OPERATING_CHARTER.md
  - README.md
  - HARNESS_ENGINEERING_CONTRACT.md
  - PIPELINE_PLAIN_GUIDE.md
last_updated: 2026-04-16
---

# AGENTS

## Core Mission

이 저장소의 목표는 하나다.

`공식 기술 문서와 운영 자료를 수집·정제·연결해, 사람이 읽는 Playbook Library와 챗봇이 쓰는 고품질 코퍼스를 같은 기준선 위에서 제공하는 제품을 만든다.`

현재 검증 범위는 아래다.

- `OpenShift 4.20 official source-first validated pack`
- `customer/private document PoC`
- `buyer/demo/release packet support`

## Active Rule Set

이 저장소의 active 문서는 아래 다섯 개뿐이다.

1. `AGENTS.md`
2. `PROJECT.md`
3. `RUNTIME_ARCHITECTURE_CONTRACT.md`
4. `EXECUTION_HARNESS_CONTRACT.md`
5. `SECURITY_BOUNDARY_CONTRACT.md`

그 외 루트 문서, 설명서, 예전 계약서는 모두 `reference or archive` 로 취급한다.
Codex 는 기본적으로 위 다섯 개만 읽고 작업한다.

## Precedence

기본 우선순위는 아래다.

1. `AGENTS.md`
2. `PROJECT.md`
3. `RUNTIME_ARCHITECTURE_CONTRACT.md`
4. `EXECUTION_HARNESS_CONTRACT.md`

단, `customer/private documents`, `remote provider egress`, `mixed official/private output` 이 걸리는 작업에서는  
`SECURITY_BOUNDARY_CONTRACT.md` 가 위 2~4번보다 우선한다.

## Task-Based Read Matrix

컨텍스트 폭주를 막기 위해 작업 종류별 최소 읽기 세트를 고정한다.

### Always

모든 작업은 아래 세 문서만 먼저 읽는다.

- `AGENTS.md`
- `PROJECT.md`
- `EXECUTION_HARNESS_CONTRACT.md`

### Add Runtime Contract When

아래 중 하나라도 해당되면 `RUNTIME_ARCHITECTURE_CONTRACT.md` 를 추가로 읽는다.

- ingest / parse / normalize
- corpus / chunk / retrieval / citation
- viewer / library / workspace
- one-click runtime
- relation / figure / anchor / manifest

### Add Security Contract When

아래 중 하나라도 해당되면 `SECURITY_BOUNDARY_CONTRACT.md` 를 추가로 읽는다.

- customer or private document lane
- tenant / workspace / pack identity
- remote model or provider egress
- official/private bridge
- mixed answer or mixed viewer output

### Do Not Read By Default

아래 문서는 사용자가 명시적으로 요청하지 않는 한 기본 컨텍스트에 넣지 않는다.

- old `README.md`
- `PIPELINE_PLAIN_GUIDE.md`
- old `CODEX_OPERATING_CHARTER.md`
- old `HARNESS_ENGINEERING_CONTRACT.md`
- any archived root contracts

## Locked Terms

용어 혼선을 막기 위해 아래 표현을 고정한다.

- `Playbook Library`
  - 책장, 후보군, active runtime, 상태 확인을 다루는 진입면
  - `Control Tower` 는 별도 최상위 surface 가 아니라 Playbook Library 안의 상태/운영 view 로 본다.
- `Wiki Runtime Viewer`
  - 본문 읽기와 위키 탐색을 담당하는 읽기 면
- `Chat Workspace`
  - grounded answer, citation, next play 를 담당하는 대화 면
- `Corpus`
  - 챗봇 검색용 chunk, sparse/vector index, citation context 묶음
- `Structured Wiki Runtime`
  - `structured book + relation assets + figure assets + runtime manifest + citation map`
- `Markdown`
  - review/export/generated artifact 일 수는 있어도, 단독 진실 소스는 아니다.

## Operating Posture

- `한 milestone = 한 execution packet`
- `작업은 active contract 에서 시작한다`
- `legacy 문서를 기준으로 판단하지 않는다`
- `제품 목표는 고정하고 구현 방식은 탐험한다`
- `더 나은 encyclopedia experience 가 나오면 기존 layout 을 과감히 바꾼다`

## User-Facing Reporting Shape

사용자 보고는 아래 두 지점으로 고정한다.

1. `milestone kickoff`
2. `milestone closeout`

closeout 에는 아래를 짧게 모아 보여준다.

- `현재 판단`
- `핵심 근거`
- `산출물 경로`
- `검증 결과`
- `가장 효과가 큰 다음 행동`

중간 메모와 시행착오는 worklog 에만 적재한다.

## Escalate Only When

아래 네 가지는 사용자 판단을 요청한다.

- 제품 방향 변경
- 파괴적 삭제
- 외부 비용 또는 보안 판단
- active contract 충돌

그 외 문제는 lane 안에서 복구하고 계속 진행한다.

## Legacy Isolation Rule

이 파일 셋을 도입할 때 기존 지침서는 루트 active set 에서 격리한다.

권장 방식:

- old docs -> `archive/legacy_contracts/`
- new active docs -> repo root
- `README.md` 는 사람이 읽는 참고 문서로만 유지하거나 제거한다

active 판단이 필요할 때는 오직 이 파일의 `Active Rule Set` 만 본다.
